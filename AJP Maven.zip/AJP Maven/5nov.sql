create database anudiphiber;
use anudiphiber;
show tables;
select * from employee;